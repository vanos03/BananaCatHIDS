$script = 'Write-Host "Привет из реестра!"'
$script_name = "BananaCat"
$reg_path = "HKCU:\Software\MyApp"


Set-ItemProperty -Path $reg_path -Name $script_name -Value $script
